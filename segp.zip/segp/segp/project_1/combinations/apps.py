from django.apps import AppConfig


class CombinationsConfig(AppConfig):
    name = 'combinations'

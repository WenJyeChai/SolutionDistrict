


def paper_relevency(paper,combination_query):
    print(paper.keywords)
    print(paper.abstract)
    print(paper.title)
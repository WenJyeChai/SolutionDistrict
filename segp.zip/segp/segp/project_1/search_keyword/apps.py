from django.apps import AppConfig


class SearchKeywordConfig(AppConfig):
    name = 'search_keyword'

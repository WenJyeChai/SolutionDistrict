from django.apps import AppConfig


class PaperAuthorConfig(AppConfig):
    name = 'paper_author'

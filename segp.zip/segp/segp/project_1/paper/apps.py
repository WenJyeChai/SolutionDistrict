from django.apps import AppConfig


class PaperConfig(AppConfig):
    name = 'paper'

from django.contrib import admin
from .models import Subcategory

# Register your models here.
admin.site.register(Subcategory)

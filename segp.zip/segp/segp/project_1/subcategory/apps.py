from django.apps import AppConfig


class SubcategoryConfig(AppConfig):
    name = 'subcategory'
